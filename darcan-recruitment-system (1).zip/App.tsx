
import React, { useState, useEffect } from 'react';
import { User, UserRole, Job, OnlineTest, Application, ApplicationStatus, ManagerRestrictions, SystemConfig, Notification } from './types';
import { ADMIN_USER, INITIAL_JOBS, INITIAL_TESTS, INITIAL_APPLICATIONS } from './constants';
import Sidebar from './components/Sidebar';
import CandidateNavbar from './components/CandidateNavbar';
import NotificationPanel from './components/NotificationPanel';
import LandingPage from './views/LandingPage';
import ManagerDashboard from './views/ManagerDashboard';
import AdminDashboard from './views/AdminDashboard';
import ManagerJobs from './views/ManagerJobs';
import ManagerCandidates from './views/ManagerCandidates';
import ManagerTests from './views/ManagerTests';
import TestReview from './views/TestReview';
import ManagerInterviews from './views/ManagerInterviews';
import AdminSettings from './views/AdminSettings';
import AdminSystemSettings from './views/AdminSystemSettings';
import CandidatePortal from './views/CandidatePortal';
import StaffProfile from './views/StaffProfile';
import AuthPage from './views/AuthPage';
import { Menu, Search, Bell } from 'lucide-react';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeView, setActiveView] = useState('dashboard');
  const [authMode, setAuthMode] = useState<'LOGIN' | 'REGISTER' | 'NONE'>('NONE');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  
  const [jobs, setJobs] = useState<Job[]>(INITIAL_JOBS);
  const [tests, setTests] = useState<OnlineTest[]>(INITIAL_TESTS);
  const [applications, setApplications] = useState<Application[]>(INITIAL_APPLICATIONS);
  
  const [systemConfig, setSystemConfig] = useState<SystemConfig>({
    companyName: 'Darcan',
    allowNewRegistrations: true,
    auditLogsEnabled: true,
    notificationEmail: 'rh@darcan.com',
    enableNotifications: true
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  const addNotification = (notif: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    if (!systemConfig.enableNotifications) return;
    
    const newNotif: Notification = {
      ...notif,
      id: `notif-${Date.now()}`,
      timestamp: new Date().toISOString(),
      read: false
    };
    setNotifications(prev => [newNotif, ...prev].slice(0, 50));
  };

  const [managers, setManagers] = useState<User[]>([
    { id: 'mgr-1', name: 'Gestor Darcan', email: 'gestor@darcan.com', role: UserRole.MANAGER, restrictions: { disabledModules: [] } },
    { id: 'm1', name: 'Ana Gestora', email: 'ana@darcan.com', role: UserRole.MANAGER, restrictions: { disabledModules: ['reports', 'comms'] } },
    { id: 'm2', name: 'Carlos RH', email: 'carlos@darcan.com', role: UserRole.MANAGER, restrictions: { disabledModules: ['tests'] } },
  ]);

  const handleLogin = (role: UserRole) => {
    if (role === UserRole.ADMIN) {
      setUser(ADMIN_USER);
      setActiveView('dashboard');
    } else if (role === UserRole.CANDIDATE) {
      setUser({ id: 'cand-1', name: 'João Silva', email: 'joao@email.com', role: UserRole.CANDIDATE });
      setActiveView('jobs'); 
    } else {
      setUser(managers[0]);
      setActiveView('dashboard');
    }
    setAuthMode('NONE');
  };

  const handleLogout = () => {
    setUser(null);
    setAuthMode('NONE');
    setActiveView('landing');
    setIsSidebarOpen(false);
  };

  const updateApplicationStatus = (appId: string, status: ApplicationStatus) => {
    setApplications(prev => prev.map(a => {
      if (a.id === appId) {
        const updates: Partial<Application> = { status };
        if (status === ApplicationStatus.APPROVED_FOR_INTERVIEW && !a.interviewDate) {
          updates.interviewDate = new Date(Date.now() + 86400000 * 2).toISOString();
        }
        return { ...a, ...updates };
      }
      return a;
    }));
  };

  const applyToJob = (jobId: string, cvUrl: string) => {
    if (!user) return;
    const job = jobs.find(j => j.id === jobId);
    const newApp: Application = {
      id: `app-${Date.now()}`,
      jobId,
      candidateId: user.id,
      status: ApplicationStatus.PENDING_CV,
      appliedAt: new Date().toISOString(),
      cvUrl
    };
    setApplications([...applications, newApp]);
    
    addNotification({
      type: 'NEW_APPLICATION',
      title: 'Nova Candidatura',
      message: `Candidato ${user.id} inscreveu-se para: ${job?.title || jobId}`
    });
    
    setTimeout(() => {
      setApplications(prev => prev.map(a => 
        a.id === newApp.id ? { ...a, status: ApplicationStatus.PENDING_TEST } : a
      ));
    }, 2000);
  };

  const finishTest = (appId: string, score: number) => {
    const app = applications.find(a => a.id === appId);
    const job = jobs.find(j => j.id === app?.jobId);
    
    setApplications(prev => prev.map(a => 
      a.id === appId ? { 
        ...a, 
        status: ApplicationStatus.PENDING_REVIEW, 
        testScore: score, 
        testCompletedAt: new Date().toISOString() 
      } : a
    ));

    addNotification({
      type: 'TEST_COMPLETED',
      title: 'Teste Concluído',
      message: `Candidato ${app?.candidateId} finalizou o teste de ${job?.title} com ${score.toFixed(0)}%`
    });
  };

  const handleSaveTest = (test: OnlineTest) => {
    setTests(prev => {
      const exists = prev.some(t => t.id === test.id);
      if (exists) {
        return prev.map(t => t.id === test.id ? test : t);
      }
      return [...prev, test];
    });
  };

  if (!user && authMode === 'NONE') {
    return (
      <LandingPage 
        onLogin={() => setAuthMode('LOGIN')} 
        onRegister={() => setAuthMode('REGISTER')} 
        onExploreJobs={() => setAuthMode('LOGIN')} 
      />
    );
  }

  if (authMode !== 'NONE') {
    return (
      <AuthPage 
        initialMode={authMode === 'REGISTER' ? 'REGISTER' : 'LOGIN'}
        onAuth={handleLogin}
        onBack={() => setAuthMode('NONE')}
        companyName={systemConfig.companyName}
      />
    );
  }

  return (
    <div className="min-h-screen bg-green-50/20">
      {user?.role === UserRole.CANDIDATE ? (
        <div className="flex flex-col h-screen overflow-auto">
          <CandidateNavbar 
            userName={user.name} 
            onLogout={handleLogout} 
            activeTab={activeView} 
            setActiveTab={setActiveView} 
          />
          <main className="flex-1">
            <CandidatePortal 
              user={user} 
              applications={applications} 
              onApply={applyToJob} 
              onFinishTest={finishTest}
              activeTab={activeView}
              setActiveTab={setActiveView}
            />
          </main>
        </div>
      ) : (
        <div className="flex min-h-screen">
          <Sidebar 
            role={user!.role} 
            activeView={activeView} 
            setActiveView={setActiveView} 
            onLogout={handleLogout}
            restrictions={user?.restrictions}
            isOpen={isSidebarOpen}
            setIsOpen={setIsSidebarOpen}
          />
          <div className="flex-1 flex flex-col min-w-0 transition-all duration-300 lg:ml-64">
            <header className="bg-white border-b border-green-50 h-16 flex items-center justify-between px-6 sticky top-0 z-40">
               <div className="flex items-center gap-4">
                 <button 
                   onClick={() => setIsSidebarOpen(true)}
                   className="p-2 rounded-lg hover:bg-green-50 lg:hidden text-green-700"
                 >
                   <Menu size={24} />
                 </button>
                 <div className="hidden sm:flex items-center bg-gray-50 px-4 py-2 rounded-xl w-64 lg:w-96 border border-gray-100">
                    <Search size={16} className="text-gray-400 mr-2" />
                    <input type="text" placeholder="Pesquisar no portal..." className="bg-transparent outline-none text-sm w-full" />
                 </div>
               </div>

               <div className="flex items-center gap-3 sm:gap-6">
                 <div className="relative">
                   <button 
                     onClick={() => setShowNotifications(!showNotifications)}
                     className="p-2.5 bg-gray-50 rounded-xl text-gray-500 hover:bg-green-50 hover:text-green-600 transition-all relative"
                   >
                     <Bell size={20} />
                     {systemConfig.enableNotifications && unreadCount > 0 && (
                       <span className="absolute -top-1 -right-1 w-5 h-5 bg-green-600 text-white text-[10px] font-black rounded-full flex items-center justify-center border-2 border-white animate-bounce">
                         {unreadCount}
                       </span>
                     )}
                   </button>

                   {showNotifications && (
                     <NotificationPanel 
                       notifications={notifications}
                       onMarkAsRead={(id) => setNotifications(prev => prev.map(n => n.id === id ? {...n, read: true} : n))}
                       onMarkAllAsRead={() => setNotifications(prev => prev.map(n => ({...n, read: true})))}
                       onClose={() => setShowNotifications(false)}
                     />
                   )}
                 </div>

                 <div className="flex items-center gap-3 pl-4 border-l border-gray-100">
                    <div className="hidden sm:block text-right">
                      <p className="text-xs font-bold text-gray-900 leading-none">{user?.name}</p>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">
                        {user?.role === UserRole.ADMIN ? 'Administrador' : 'Gestor de RH'}
                      </p>
                    </div>
                    <button 
                      onClick={() => setActiveView('profile')}
                      className={`w-10 h-10 rounded-xl text-white flex items-center justify-center font-bold shadow-lg shadow-green-100 transition-transform overflow-hidden active:scale-95 ${user?.role === UserRole.ADMIN ? 'bg-slate-900' : 'bg-green-700'}`}
                    >
                      {user?.avatar ? (
                        <img src={user.avatar} className="w-full h-full object-cover" alt="User Avatar" />
                      ) : (
                        user?.name.charAt(0)
                      )}
                    </button>
                 </div>
               </div>
            </header>

            <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-x-hidden">
              {activeView === 'dashboard' && (
                user?.role === UserRole.ADMIN ? <AdminDashboard /> : <ManagerDashboard />
              )}
              {activeView === 'profile' && user && (
                <StaffProfile user={user} onUpdateUser={(updates) => setUser({...user, ...updates})} />
              )}
              {activeView === 'jobs' && <ManagerJobs jobs={jobs} tests={tests} onAddJob={(j) => setJobs([...jobs, {...j, id: `job-${Date.now()}`} as Job])} onUpdateJob={(id, upd) => setJobs(jobs.map(j => j.id === id ? {...j, ...upd} : j))} onDeleteJob={(id) => setJobs(jobs.filter(j => j.id !== id))} />}
              {activeView === 'candidates' && <ManagerCandidates applications={applications} jobs={jobs} onUpdateStatus={updateApplicationStatus} />}
              {activeView === 'tests' && <ManagerTests tests={tests} onAddTest={handleSaveTest} />}
              {activeView === 'test-review' && <TestReview applications={applications} jobs={jobs} onUpdateStatus={updateApplicationStatus} />}
              {activeView === 'interviews' && <ManagerInterviews applications={applications} jobs={jobs} />}
              {activeView === 'admin' && (
                <AdminSettings 
                  managers={managers} 
                  onUpdateManagerPermissions={(id, res) => setManagers(prev => prev.map(m => m.id === id ? {...m, restrictions: res} : m))}
                  onAddManager={(m) => setManagers([...managers, {...m, id: `mgr-${Date.now()}`, role: UserRole.MANAGER} as User])}
                />
              )}
              {activeView === 'settings' && (
                <AdminSystemSettings 
                  systemConfig={systemConfig}
                  onUpdateSystemConfig={setSystemConfig}
                />
              )}
              {['comms', 'reports'].includes(activeView) && (
                <div className="bg-white p-10 sm:p-20 rounded-3xl border-2 border-dashed border-green-100 flex flex-col items-center justify-center text-center">
                  <div className="p-6 bg-green-50 rounded-full text-green-600 mb-6"><span className="text-4xl">🚧</span></div>
                  <h2 className="text-2xl font-bold text-gray-900">Em Desenvolvimento</h2>
                  <button onClick={() => setActiveView('dashboard')} className="mt-8 px-8 py-3 bg-green-600 text-white rounded-xl font-bold">Voltar</button>
                </div>
              )}
            </main>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
