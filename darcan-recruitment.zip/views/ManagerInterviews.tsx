
import React from 'react';
import { Application, Job } from '../types';
import { Calendar, Clock, MapPin, User } from 'lucide-react';

interface ManagerInterviewsProps {
  applications: Application[];
  jobs: Job[];
}

const ManagerInterviews: React.FC<ManagerInterviewsProps> = ({ applications, jobs }) => {
  const upcomingInterviews = applications.filter(a => a.interviewDate);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-900">Agenda de Entrevistas</h1>
        <p className="text-gray-500">Coordene os encontros presenciais e avaliações finais.</p>
      </header>

      <div className="space-y-4">
          <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Próximas Entrevistas</h3>
          {upcomingInterviews.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-green-50 text-center flex flex-col items-center">
              <Calendar className="text-gray-200 mb-4" size={48} />
              <p className="text-gray-500">Nenhuma entrevista agendada para os próximos dias.</p>
            </div>
          ) : (
            upcomingInterviews.map(app => {
              const job = jobs.find(j => j.id === app.jobId);
              return (
                <div key={app.id} className="bg-white p-5 rounded-2xl border border-green-50 shadow-sm flex flex-col md:flex-row gap-4 items-start md:items-center justify-between hover:shadow-md transition-all">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-700">
                      <Calendar size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">ID: {app.candidateId}</h4>
                      <p className="text-xs font-medium text-green-600">{job?.title}</p>
                      <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                        <span className="flex items-center gap-1"><Clock size={12}/> {new Date(app.interviewDate!).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        <span className="flex items-center gap-1"><MapPin size={12}/> Sede Principal</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  };

export default ManagerInterviews;
