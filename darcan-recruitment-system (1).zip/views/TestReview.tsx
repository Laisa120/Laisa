
import React from 'react';
import { Application, ApplicationStatus, Job } from '../types';
import { ClipboardCheck, CheckCircle, XCircle, User as UserIcon, Clock, AlertCircle } from 'lucide-react';

interface TestReviewProps {
  applications: Application[];
  jobs: Job[];
  onUpdateStatus: (appId: string, status: ApplicationStatus) => void;
}

const TestReview: React.FC<TestReviewProps> = ({ applications, jobs, onUpdateStatus }) => {
  const pendingReviews = applications.filter(app => app.status === ApplicationStatus.PENDING_REVIEW);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-900">Avaliação de Testes</h1>
        <p className="text-gray-500">Analise o desempenho dos candidatos nos testes V/F e tome decisões de contratação.</p>
      </header>

      {pendingReviews.length === 0 ? (
        <div className="bg-white py-20 rounded-3xl border-2 border-dashed border-gray-100 flex flex-col items-center justify-center text-center">
          <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center text-green-300 mb-6">
            <ClipboardCheck size={40} />
          </div>
          <h3 className="text-xl font-bold text-gray-900">Nenhum teste pendente</h3>
          <p className="text-gray-500 mt-2 max-w-sm">
            Todos os testes submetidos já foram avaliados ou não há novas submissões no momento.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {pendingReviews.map(app => {
            const job = jobs.find(j => j.id === app.jobId);
            const isPassing = (app.testScore || 0) >= 70;

            return (
              <div key={app.id} className="bg-white p-6 rounded-2xl border border-green-50 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-6 hover:border-green-200 transition-all">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-green-50 rounded-2xl flex items-center justify-center text-green-700 shrink-0">
                    <UserIcon size={28} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 text-lg">Candidato ID: {app.candidateId}</h3>
                    <p className="text-green-600 font-medium text-sm">{job?.title}</p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-gray-400 font-bold uppercase tracking-wider">
                      <span className="flex items-center gap-1"><Clock size={12}/> {new Date(app.testCompletedAt!).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-center px-8 border-x border-gray-50">
                  <span className="text-[10px] font-black text-gray-400 uppercase mb-1">Resultado do Teste</span>
                  <div className={`text-3xl font-black ${isPassing ? 'text-green-600' : 'text-amber-500'}`}>
                    {app.testScore}%
                  </div>
                  <span className={`text-[10px] font-bold mt-1 px-2 py-0.5 rounded ${isPassing ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                    {isPassing ? 'ACIMA DO MÍNIMO' : 'ABAIXO DO MÍNIMO'}
                  </span>
                </div>

                <div className="flex gap-3 w-full md:w-auto">
                  <button 
                    onClick={() => onUpdateStatus(app.id, ApplicationStatus.REJECTED)}
                    className="flex-1 md:flex-none px-6 py-3 bg-red-50 text-red-600 rounded-xl font-bold hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
                  >
                    <XCircle size={18} /> Reprovar
                  </button>
                  <button 
                    onClick={() => onUpdateStatus(app.id, ApplicationStatus.APPROVED_FOR_INTERVIEW)}
                    className="flex-1 md:flex-none px-8 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-100 flex items-center justify-center gap-2"
                  >
                    <CheckCircle size={18} /> Aprovar p/ Entrevista
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Info Box */}
      <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100 flex gap-4">
        <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-blue-600 shrink-0 shadow-sm">
          <AlertCircle size={20} />
        </div>
        <div>
          <h4 className="text-sm font-bold text-blue-900">Sobre a Avaliação Automática</h4>
          <p className="text-xs text-blue-700 leading-relaxed mt-1">
            Candidatos com pontuação superior a 70% são geralmente recomendados para a fase de entrevista. 
            No entanto, você pode revisar manualmente cada caso aqui antes de agendar o encontro final.
          </p>
        </div>
      </div>
    </div>
  );
};

export default TestReview;
