
import React, { useState, useRef, useEffect } from 'react';
import { User, UserRole } from '../types';
import { 
  Send, 
  Search, 
  MoreVertical, 
  Paperclip, 
  Smile, 
  Phone, 
  Video, 
  Circle,
  Hash,
  MessageSquare,
  Users,
  ShieldCheck,
  CheckCheck
} from 'lucide-react';

interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  status: 'sent' | 'delivered' | 'read';
}

interface ChatContact {
  id: string;
  name: string;
  role: UserRole;
  avatar?: string;
  lastMessage?: string;
  lastMessageTime?: string;
  online: boolean;
  unreadCount: number;
}

interface ManagerCommunicationProps {
  currentUser: User;
}

const ManagerCommunication: React.FC<ManagerCommunicationProps> = ({ currentUser }) => {
  const isAdmin = currentUser.role === UserRole.ADMIN;
  const [searchTerm, setSearchTerm] = useState('');
  const [messageInput, setMessageInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Mock de contatos (Equipa Darcan)
  const [contacts] = useState<ChatContact[]>([
    { id: 'admin-001', name: 'Administrador Darcan', role: UserRole.ADMIN, online: true, lastMessage: 'As novas diretrizes de recrutamento foram atualizadas.', lastMessageTime: '10:30', unreadCount: 0, avatar: 'https://picsum.photos/seed/admin/100' },
    { id: 'mgr-1', name: 'Ana Gestora', role: UserRole.MANAGER, online: true, lastMessage: 'Podes rever o teste do candidato João?', lastMessageTime: '09:45', unreadCount: 2, avatar: 'https://picsum.photos/seed/ana/100' },
    { id: 'mgr-2', name: 'Carlos RH', role: UserRole.MANAGER, online: false, lastMessage: 'Combinado, tratamos disso na reunião.', lastMessageTime: 'Ontem', unreadCount: 0, avatar: 'https://picsum.photos/seed/carlos/100' },
    { id: 'staff-1', name: 'Suporte Técnico', role: UserRole.ADMIN, online: true, lastMessage: 'O módulo de relatórios está estável.', lastMessageTime: '11:20', unreadCount: 0 },
  ]);

  const [selectedContact, setSelectedContact] = useState<ChatContact>(contacts[1]);

  const [messages, setMessages] = useState<Message[]>([
    { id: '1', senderId: 'mgr-1', text: 'Olá! Como vai o processo para a vaga de Professor de Matemática?', timestamp: '09:40', status: 'read' },
    { id: '2', senderId: currentUser.id, text: 'Olá Ana! Já temos 3 candidatos em fase de revisão de teste.', timestamp: '09:42', status: 'read' },
    { id: '3', senderId: 'mgr-1', text: 'Ótimo. Podes rever o teste do candidato João? Acho que ele tem muito potencial.', timestamp: '09:45', status: 'delivered' },
  ]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      senderId: currentUser.id,
      text: messageInput,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'sent'
    };

    setMessages([...messages, newMessage]);
    setMessageInput('');

    // Simulação de resposta automática após 2 segundos
    setTimeout(() => {
      const reply: Message = {
        id: (Date.now() + 1).toString(),
        senderId: selectedContact.id,
        text: 'Recebido. Vou verificar agora mesmo.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'sent'
      };
      setMessages(prev => [...prev, reply]);
    }, 2000);
  };

  const filteredContacts = contacts.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-[calc(100vh-140px)] flex bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Sidebar de Contatos */}
      <aside className="w-full md:w-80 flex flex-col border-r border-gray-50 bg-gray-50/30">
        <div className="p-6">
          <h2 className="text-xl font-black text-gray-900 mb-4 flex items-center gap-2">
            <MessageSquare size={24} className={isAdmin ? 'text-slate-900' : 'text-green-700'} />
            Conversas
          </h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Procurar equipa..."
              className="w-full pl-10 pr-4 py-3 bg-white border-none rounded-2xl text-sm font-medium text-black focus:ring-2 focus:ring-green-500 transition-all shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar px-3">
          <div className="space-y-1">
            {filteredContacts.map(contact => (
              <button
                key={contact.id}
                onClick={() => setSelectedContact(contact)}
                className={`w-full p-4 rounded-2xl flex items-center gap-4 transition-all relative group ${
                  selectedContact.id === contact.id 
                  ? (isAdmin ? 'bg-slate-900 text-white shadow-lg' : 'bg-green-700 text-white shadow-lg')
                  : 'hover:bg-white text-gray-600'
                }`}
              >
                <div className="relative shrink-0">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg overflow-hidden border-2 ${
                    selectedContact.id === contact.id ? 'border-white/20' : 'border-gray-100 bg-white'
                  }`}>
                    {contact.avatar ? (
                      <img src={contact.avatar} alt={contact.name} className="w-full h-full object-cover" />
                    ) : (
                      contact.name.charAt(0)
                    )}
                  </div>
                  {contact.online && (
                    <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full" />
                  )}
                </div>

                <div className="flex-1 text-left min-w-0">
                  <div className="flex justify-between items-center mb-0.5">
                    <h4 className="font-bold truncate text-sm">{contact.name}</h4>
                    <span className={`text-[10px] font-medium ${selectedContact.id === contact.id ? 'text-white/60' : 'text-gray-400'}`}>
                      {contact.lastMessageTime}
                    </span>
                  </div>
                  <p className={`text-xs truncate ${selectedContact.id === contact.id ? 'text-white/70' : 'text-gray-400'}`}>
                    {contact.lastMessage}
                  </p>
                </div>

                {contact.unreadCount > 0 && selectedContact.id !== contact.id && (
                  <div className="absolute top-4 right-4 w-5 h-5 bg-emerald-500 text-white text-[10px] font-black rounded-full flex items-center justify-center border-2 border-white">
                    {contact.unreadCount}
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      </aside>

      {/* Janela de Chat Principal */}
      <main className="flex-1 flex flex-col bg-white">
        {/* Header do Chat */}
        <header className="px-8 py-4 border-b border-gray-50 flex justify-between items-center bg-white/80 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center font-bold text-gray-400 border border-gray-100 overflow-hidden">
                {selectedContact.avatar ? (
                  <img src={selectedContact.avatar} alt={selectedContact.name} className="w-full h-full object-cover" />
                ) : (
                  selectedContact.name.charAt(0)
                )}
              </div>
              {selectedContact.online && (
                <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-gray-900">{selectedContact.name}</h3>
                <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest ${
                  selectedContact.role === UserRole.ADMIN ? 'bg-slate-100 text-slate-900' : 'bg-green-100 text-green-700'
                }`}>
                  {selectedContact.role}
                </span>
              </div>
              <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-wider">
                {selectedContact.online ? 'Online Agora' : 'Visto pela última vez ontem'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button className="p-2.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-xl transition-all"><Phone size={20} /></button>
            <button className="p-2.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-xl transition-all"><Video size={20} /></button>
            <button className="p-2.5 text-gray-400 hover:text-gray-900 hover:bg-gray-50 rounded-xl transition-all"><MoreVertical size={20} /></button>
          </div>
        </header>

        {/* Área de Mensagens */}
        <div className="flex-1 overflow-y-auto p-8 space-y-6 bg-gray-50/20 custom-scrollbar">
          <div className="flex justify-center mb-8">
            <span className="px-4 py-1.5 bg-white border border-gray-100 rounded-full text-[10px] font-black text-gray-400 uppercase tracking-widest shadow-sm">
              Hoje, {new Date().toLocaleDateString()}
            </span>
          </div>

          {messages.map((msg) => {
            const isMe = msg.senderId === currentUser.id;
            return (
              <div 
                key={msg.id} 
                className={`flex ${isMe ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}
              >
                <div className={`max-w-[70%] group ${isMe ? 'items-end' : 'items-start'}`}>
                  <div className={`px-5 py-3.5 rounded-3xl text-sm font-bold shadow-sm transition-all ${
                    isMe 
                    ? (isAdmin ? 'bg-slate-100 text-black border border-slate-200 rounded-tr-none' : 'bg-green-100 text-black border border-green-200 rounded-tr-none')
                    : 'bg-white text-black border border-gray-100 rounded-tl-none'
                  }`}>
                    {msg.text}
                  </div>
                  <div className={`flex items-center gap-2 mt-1.5 px-1 ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <span className="text-[10px] font-bold text-gray-400">{msg.timestamp}</span>
                    {isMe && (
                      <span className={msg.status === 'read' ? 'text-emerald-500' : 'text-gray-300'}>
                        <CheckCheck size={14} />
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Rodapé de Entrada */}
        <footer className="p-6 bg-white border-t border-gray-50">
          <form 
            onSubmit={handleSendMessage}
            className="flex items-center gap-4"
          >
            <div className="flex gap-2">
              <button type="button" className="p-3 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-2xl transition-all">
                <Paperclip size={20} />
              </button>
              <button type="button" className="p-3 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-2xl transition-all">
                <Smile size={20} />
              </button>
            </div>
            
            <input 
              type="text" 
              placeholder="Escreve a tua mensagem aqui..."
              className="flex-1 px-6 py-4 bg-gray-50 border-none rounded-[2rem] text-sm font-medium text-black focus:ring-2 focus:ring-green-600 outline-none transition-all"
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
            />

            <button 
              type="submit"
              disabled={!messageInput.trim()}
              className={`p-4 rounded-2xl text-white shadow-lg transition-all transform active:scale-95 disabled:opacity-50 disabled:scale-100 ${
                isAdmin ? 'bg-slate-900 shadow-slate-200' : 'bg-green-700 shadow-green-100'
              }`}
            >
              <Send size={24} />
            </button>
          </form>
        </footer>
      </main>

      {/* Painel de Detalhes lateral (Escondido em mobile) */}
      <aside className="hidden lg:flex w-72 border-l border-gray-50 flex-col p-8 bg-white">
        <div className="text-center mb-8">
           <div className="w-24 h-24 rounded-3xl bg-gray-50 mx-auto mb-4 border-4 border-white shadow-xl flex items-center justify-center font-bold text-4xl text-gray-300 overflow-hidden">
             {selectedContact.avatar ? (
                <img src={selectedContact.avatar} alt={selectedContact.name} className="w-full h-full object-cover" />
              ) : (
                selectedContact.name.charAt(0)
              )}
           </div>
           <h3 className="text-lg font-black text-gray-900">{selectedContact.name}</h3>
           <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mt-1">{selectedContact.role}</p>
        </div>

        <div className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-2xl">
            <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Sobre</h4>
            <p className="text-xs text-gray-600 leading-relaxed">
              Membro da equipa Darcan desde 2023. Responsável pela gestão de processos na área de {selectedContact.role === UserRole.ADMIN ? 'Tecnologia' : 'Educação'}.
            </p>
          </div>

          <div className="space-y-3">
            <button className="w-full py-3 bg-white border border-gray-100 text-gray-700 rounded-xl font-bold text-xs hover:bg-gray-50 transition-colors flex items-center justify-center gap-2">
              <Users size={16} className="text-green-600" /> Ver Perfil Completo
            </button>
            <button className="w-full py-3 bg-white border border-gray-100 text-gray-700 rounded-xl font-bold text-xs hover:bg-gray-50 transition-colors flex items-center justify-center gap-2">
              <ShieldCheck size={16} className="text-green-600" /> Permissões de Equipa
            </button>
          </div>
        </div>

        <div className="mt-auto pt-8">
           <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
             <p className="text-[10px] font-bold text-amber-800 leading-tight">
               As mensagens enviadas no portal Darcan são encriptadas e monitorizadas para fins de auditoria.
             </p>
           </div>
        </div>
      </aside>
    </div>
  );
};

export default ManagerCommunication;
