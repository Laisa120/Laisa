
import React, { useState } from 'react';
import { Application, ApplicationStatus, Job, User } from '../types';
import { Search, Filter, CheckCircle, XCircle, User as UserIcon, FileText, Ban } from 'lucide-react';

interface ManagerCandidatesProps {
  applications: Application[];
  jobs: Job[];
  onUpdateStatus: (appId: string, status: ApplicationStatus) => void;
}

const ManagerCandidates: React.FC<ManagerCandidatesProps> = ({ applications, jobs, onUpdateStatus }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const filteredApps = applications.filter(app => {
    const job = jobs.find(j => j.id === app.jobId);
    const matchesSearch = job?.title.toLowerCase().includes(searchTerm.toLowerCase()) || app.candidateId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || app.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-900">Gestão de Candidatos</h1>
        <p className="text-gray-500">Analise currículos e gerencie o progresso dos talentos.</p>
      </header>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-green-50">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Pesquisar por vaga ou candidato..." 
              className="w-full pl-10 pr-4 py-2 bg-gray-50 rounded-lg border-transparent focus:bg-white focus:border-green-500 outline-none transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <select 
            className="px-4 py-2 bg-gray-50 rounded-lg border-transparent focus:bg-white focus:border-green-500 outline-none"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="ALL">Todos os Status</option>
            <option value={ApplicationStatus.PENDING_CV}>CV Pendente</option>
            <option value={ApplicationStatus.PENDING_TEST}>Aprovado p/ Teste</option>
            <option value={ApplicationStatus.PENDING_REVIEW}>Em Avaliação</option>
            <option value={ApplicationStatus.APPROVED_FOR_INTERVIEW}>Entrevista</option>
            <option value={ApplicationStatus.REJECTED}>Reprovado</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-xs font-bold text-gray-400 uppercase tracking-wider border-b border-gray-50">
                <th className="pb-4 pl-4">Candidato / Vaga</th>
                <th className="pb-4">Status Atual</th>
                <th className="pb-4">Nota Teste</th>
                <th className="pb-4">Data Inscrição</th>
                <th className="pb-4 pr-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredApps.map(app => {
                const job = jobs.find(j => j.id === app.jobId);
                return (
                  <tr key={app.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="py-4 pl-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-700">
                          <UserIcon size={20} />
                        </div>
                        <div>
                          <div className="font-bold text-gray-900">ID: {app.candidateId}</div>
                          <div className="text-xs text-green-600 font-medium">{job?.title}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4">
                      <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-bold">
                        {app.status}
                      </span>
                    </td>
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        {app.testScore !== undefined ? (
                          <span className={`font-bold ${app.testScore >= 70 ? 'text-green-600' : 'text-orange-600'}`}>
                            {app.testScore}%
                          </span>
                        ) : (
                          <span className="text-gray-300">N/A</span>
                        )}
                      </div>
                    </td>
                    <td className="py-4 text-sm text-gray-500">
                      {new Date(app.appliedAt).toLocaleDateString()}
                    </td>
                    <td className="py-4 pr-4 text-right">
                      <div className="flex justify-end gap-2">
                        {app.status === ApplicationStatus.PENDING_CV && (
                          <>
                            <button 
                              onClick={() => onUpdateStatus(app.id, ApplicationStatus.PENDING_TEST)}
                              className="p-2 text-green-600 hover:bg-green-50 rounded-lg title='Aprovar CV'"
                            >
                              <CheckCircle size={18} />
                            </button>
                            <button 
                              onClick={() => onUpdateStatus(app.id, ApplicationStatus.REJECTED)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg title='Reprovar'"
                            >
                              <XCircle size={18} />
                            </button>
                          </>
                        )}
                        <button className="p-2 text-gray-400 hover:text-gray-600 title='Ver Currículo'">
                          <FileText size={18} />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-red-800 title='Bloquear Candidato'">
                          <Ban size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ManagerCandidates;
