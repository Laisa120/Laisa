
export enum UserRole {
  ADMIN = 'ADMIN',
  MANAGER = 'MANAGER',
  CANDIDATE = 'CANDIDATE'
}

export enum ApplicationStatus {
  PENDING_CV = 'PENDING_CV',
  PENDING_TEST = 'PENDING_TEST',
  TEST_IN_PROGRESS = 'TEST_IN_PROGRESS',
  PENDING_REVIEW = 'PENDING_REVIEW',
  APPROVED_FOR_INTERVIEW = 'APPROVED_FOR_INTERVIEW',
  INTERVIEWED = 'INTERVIEWED',
  REJECTED = 'REJECTED',
  HIRED = 'HIRED'
}

export interface ManagerRestrictions {
  disabledModules: string[];
}

export interface SystemConfig {
  companyName: string;
  allowNewRegistrations: boolean;
  auditLogsEnabled: boolean;
  notificationEmail: string;
  enableNotifications: boolean; // Nova opção de notificação
  heroImages: string[];
  logoUrl: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  restrictions?: ManagerRestrictions;
}

export interface Job {
  id: string;
  title: string;
  department: string;
  description: string;
  requirements: string[];
  status: 'OPEN' | 'PAUSED' | 'ARCHIVED';
  createdAt: string;
  deadline: string;
  testId?: string;
}

export interface Question {
  id: string;
  text: string;
  type: 'MULTIPLE_CHOICE' | 'TRUE_FALSE' | 'DISCURSIVE';
  options?: string[];
  correctAnswer?: string;
  points: number;
}

export interface OnlineTest {
  id: string;
  title: string;
  questions: Question[];
  timeLimitMinutes: number;
  minPassScore: number;
}

export interface Application {
  id: string;
  jobId: string;
  candidateId: string;
  status: ApplicationStatus;
  appliedAt: string;
  cvUrl: string;
  testScore?: number;
  testCompletedAt?: string;
  interviewDate?: string;
  feedback?: string;
  blockedUntil?: string; 
}

export interface Activity {
  id: string;
  userId: string;
  userName: string;
  action: string;
  timestamp: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'NEW_APPLICATION' | 'TEST_COMPLETED' | 'INFO';
}
