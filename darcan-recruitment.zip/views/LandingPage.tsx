
import React, { useState, useEffect } from 'react';
import { ArrowRight, CheckCircle, Search, ShieldCheck, ChevronLeft, ChevronRight, Menu, X } from 'lucide-react';

interface LandingPageProps {
  onRegister: () => void;
  onLogin: () => void;
  onExploreJobs: () => void;
  heroImages: string[];
  logoUrl: string;
}

const LandingPage: React.FC<LandingPageProps> = ({ onRegister, onLogin, onExploreJobs, heroImages, logoUrl }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [heroImages.length]);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % heroImages.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + heroImages.length) % heroImages.length);

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      {/* Header */}
      <nav className="border-b border-green-50 sticky top-0 bg-white z-[60]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between h-20 items-center">
          <div className="flex items-center gap-3">
            <img 
              src={logoUrl} 
              alt="Logo Darcan" 
              className="w-10 h-10 object-contain rounded-lg"
              referrerPolicy="no-referrer"
            />
            <div className="text-2xl font-bold text-green-700">Darcan</div>
          </div>
          
          <div className="hidden md:flex gap-4">
            <button onClick={onLogin} className="px-5 py-2 text-green-700 font-medium hover:text-green-800">Entrar</button>
            <button onClick={onRegister} className="px-6 py-2 bg-green-600 text-white rounded-full font-medium hover:bg-green-700 transition-colors shadow-lg shadow-green-100">Registrar-se</button>
          </div>

          <button 
            className="md:hidden p-2 text-green-700"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {/* Mobile Menu Overlay */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-20 left-0 w-full bg-white border-b border-green-50 shadow-xl p-6 flex flex-col gap-4 animate-in slide-in-from-top duration-300">
            <button onClick={() => { onLogin(); setIsMenuOpen(false); }} className="w-full py-4 text-green-700 font-bold text-center bg-green-50 rounded-xl">Entrar</button>
            <button onClick={() => { onRegister(); setIsMenuOpen(false); }} className="w-full py-4 bg-green-600 text-white rounded-xl font-bold text-center">Registrar-se</button>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="py-12 lg:py-24 bg-green-50/30 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row items-center gap-10 lg:gap-16">
          <div className="flex-1 text-center lg:text-left order-2 lg:order-1">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 leading-tight">
              Sua carreira de <span className="text-green-600">sucesso</span> começa aqui na Darcan.
            </h1>
            <p className="mt-6 text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto lg:mx-0">
              Simplificamos o processo de recrutamento para que você encontre a vaga ideal e mostre seu potencial através de nossos testes de nivelamento.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button onClick={onExploreJobs} className="px-8 py-4 bg-green-600 text-white rounded-xl font-bold text-lg hover:bg-green-700 transition-all shadow-xl shadow-green-200 flex items-center justify-center gap-2">
                Explorar Vagas <ArrowRight size={20} />
              </button>
              <button onClick={onRegister} className="px-8 py-4 bg-white text-green-700 border-2 border-green-100 rounded-xl font-bold text-lg hover:bg-green-50 transition-all flex items-center justify-center gap-2">
                Crie seu Perfil
              </button>
            </div>
          </div>
          
          <div className="flex-1 relative group w-full max-w-2xl mx-auto order-1 lg:order-2">
            <div className="relative h-[300px] sm:h-[400px] lg:h-[500px] overflow-hidden rounded-3xl shadow-2xl border-4 sm:border-8 border-white bg-white">
              <div 
                className="flex h-full transition-transform duration-700 ease-in-out" 
                style={{ transform: `translateX(-${currentSlide * 100}%)` }}
              >
                {heroImages.map((src, i) => (
                  <img 
                    key={i} 
                    src={src} 
                    alt={`Slide ${i + 1}`} 
                    className="w-full h-full flex-shrink-0 object-cover"
                  />
                ))}
              </div>

              {/* Navigation Arrows (visible only on hover in large screens) */}
              <button 
                onClick={prevSlide}
                className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-white/80 backdrop-blur-sm rounded-full text-green-700 md:opacity-0 md:group-hover:opacity-100 transition-opacity hover:bg-white"
              >
                <ChevronLeft size={20} />
              </button>
              <button 
                onClick={nextSlide}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-white/80 backdrop-blur-sm rounded-full text-green-700 md:opacity-0 md:group-hover:opacity-100 transition-opacity hover:bg-white"
              >
                <ChevronRight size={20} />
              </button>

              {/* Indicators */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5 sm:gap-2">
                {heroImages.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentSlide(i)}
                    className={`h-2 rounded-full transition-all ${
                      currentSlide === i ? 'bg-green-600 w-4 sm:w-6' : 'bg-gray-300 w-2'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="absolute -bottom-4 sm:-bottom-6 -left-2 sm:-left-6 bg-white p-4 sm:p-6 rounded-2xl shadow-xl border border-green-50 z-10 hidden sm:block">
              <div className="flex items-center gap-3 sm:gap-4">
                <div className="p-2 sm:p-3 bg-green-100 rounded-lg text-green-600">
                  <CheckCircle size={24} />
                </div>
                <div>
                  <p className="text-sm font-bold text-gray-900">Processo Transparente</p>
                  <p className="text-xs text-gray-500">Feedback em cada etapa</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 lg:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl font-bold text-gray-900">Como funciona para você</h2>
          <p className="text-gray-500 mt-2">Um fluxo pensado na agilidade e eficiência</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-12">
          {[
            { icon: <Search className="text-green-600" size={32} />, title: "Candidatura Simples", desc: "Encontre a vaga ideal para o seu perfil e envie seu currículo em poucos cliques." },
            { icon: <ShieldCheck className="text-green-600" size={32} />, title: "Testes Online", desc: "Realize avaliações técnicas cronometradas para validar suas competências." },
            { icon: <ArrowRight className="text-green-600" size={32} />, title: "Acompanhamento", desc: "Acompanhe em tempo real o status do seu processo e receba feedbacks." },
          ].map((item, idx) => (
            <div key={idx} className="bg-white p-6 sm:p-8 rounded-2xl border border-green-50 hover:border-green-200 transition-colors group text-center sm:text-left">
              <div className="mx-auto sm:mx-0 mb-6 p-4 bg-green-50 rounded-2xl w-fit group-hover:bg-green-100 transition-colors">
                {item.icon}
              </div>
              <h3 className="text-xl font-bold mb-4 text-gray-900">{item.title}</h3>
              <p className="text-gray-600 leading-relaxed text-sm sm:text-base">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
