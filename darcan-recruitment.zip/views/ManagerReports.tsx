
import React, { useState } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, BarChart, Bar, Legend
} from 'recharts';
import { 
  Download, 
  Filter, 
  TrendingUp, 
  Users, 
  Target, 
  Clock, 
  FileText,
  Calendar,
  ChevronDown
} from 'lucide-react';

const areaData = [
  { month: 'Jan', apps: 45, hires: 12 },
  { month: 'Fev', apps: 52, hires: 15 },
  { month: 'Mar', apps: 48, hires: 10 },
  { month: 'Abr', apps: 61, hires: 18 },
  { month: 'Mai', apps: 55, hires: 20 },
  { month: 'Jun', apps: 67, hires: 22 },
  { month: 'Jul', apps: 80, hires: 25 },
];

const deptData = [
  { name: 'Educação', value: 40, color: '#059669' },
  { name: 'Tecnologia', value: 30, color: '#10b981' },
  { name: 'Administração', value: 20, color: '#34d399' },
  { name: 'Saúde', value: 10, color: '#6ee7b7' },
];

const funnelData = [
  { name: 'Candidaturas', value: 1200 },
  { name: 'Testes Realizados', value: 850 },
  { name: 'Aprovados Teste', value: 320 },
  { name: 'Entrevistas', value: 120 },
  { name: 'Contratados', value: 45 },
];

const StatCard = ({ title, value, subValue, icon: Icon, colorClass }: any) => (
  <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-md transition-all">
    <div className="flex justify-between items-start mb-4">
      <div className={`p-3 rounded-2xl ${colorClass}`}>
        <Icon size={24} />
      </div>
      <span className="flex items-center gap-1 text-emerald-600 text-xs font-bold">
        <TrendingUp size={14} /> +12%
      </span>
    </div>
    <h3 className="text-gray-500 text-xs font-black uppercase tracking-widest">{title}</h3>
    <p className="text-3xl font-black text-gray-900 mt-1">{value}</p>
    <p className="text-xs text-gray-400 mt-2 font-medium">{subValue}</p>
  </div>
);

const ManagerReports: React.FC = () => {
  const [period, setPeriod] = useState('30d');

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black text-gray-900 tracking-tight">Analytics & Relatórios</h1>
          <p className="text-gray-500 font-medium">Insights baseados em dados para otimizar o seu recrutamento.</p>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:flex-none">
            <select 
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              className="appearance-none bg-white border border-gray-100 px-6 py-3 pr-12 rounded-2xl text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-green-500 shadow-sm w-full"
            >
              <option value="7d">Últimos 7 dias</option>
              <option value="30d">Últimos 30 dias</option>
              <option value="12m">Último ano</option>
            </select>
            <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={16} />
          </div>
          
          <button className="px-6 py-3 bg-green-700 text-white rounded-2xl font-bold text-sm flex items-center gap-2 hover:bg-green-800 transition-all shadow-lg shadow-green-100">
            <Download size={18} /> Exportar <span className="hidden sm:inline">PDF</span>
          </button>
        </div>
      </header>

      {/* KPI Section */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Inscritos" 
          value="1.284" 
          subValue="Candidatos únicos este mês" 
          icon={Users} 
          colorClass="bg-blue-50 text-blue-600" 
        />
        <StatCard 
          title="Taxa de Conversão" 
          value="24.8%" 
          subValue="Aprovados vs Candidaturas" 
          icon={Target} 
          colorClass="bg-emerald-50 text-emerald-600" 
        />
        <StatCard 
          title="Tempo Médio" 
          value="18 dias" 
          subValue="Desde a vaga até à oferta" 
          icon={Clock} 
          colorClass="bg-amber-50 text-amber-600" 
        />
        <StatCard 
          title="Testes Efetuados" 
          value="842" 
          subValue="Com taxa de sucesso de 72%" 
          icon={FileText} 
          colorClass="bg-purple-50 text-purple-600" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Gráfico de Evolução */}
        <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
          <div className="flex justify-between items-center mb-8">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
              <TrendingUp className="text-green-600" size={20} /> Evolução de Candidaturas
            </h3>
            <div className="flex gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-600 rounded-full" />
                <span className="text-[10px] font-black uppercase text-gray-400">Inscritos</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-slate-300 rounded-full" />
                <span className="text-[10px] font-black uppercase text-gray-400">Contratados</span>
              </div>
            </div>
          </div>
          
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={areaData}>
                <defs>
                  <linearGradient id="colorApps" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis 
                  dataKey="month" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 12, fontWeight: 600, fill: '#94a3b8' }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 12, fontWeight: 600, fill: '#94a3b8' }} 
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="apps" 
                  stroke="#059669" 
                  strokeWidth={4} 
                  fillOpacity={1} 
                  fill="url(#colorApps)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="hires" 
                  stroke="#94a3b8" 
                  strokeWidth={2} 
                  fillOpacity={0} 
                  strokeDasharray="5 5"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Distribuição por Departamento */}
        <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm flex flex-col">
          <h3 className="font-bold text-gray-900 mb-8 flex items-center gap-2">
            <Calendar className="text-green-600" size={20} /> Por Departamento
          </h3>
          
          <div className="h-64 w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={deptData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={8}
                  dataKey="value"
                >
                  {deptData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            {/* Legend in center */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
               <div className="text-center">
                 <p className="text-2xl font-black text-gray-900">100%</p>
                 <p className="text-[10px] font-bold text-gray-400 uppercase">Atividade</p>
               </div>
            </div>
          </div>

          <div className="mt-8 space-y-4 flex-1">
            {deptData.map((item) => (
              <div key={item.name} className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-sm font-bold text-gray-600">{item.name}</span>
                </div>
                <span className="text-sm font-black text-gray-900">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Funil de Recrutamento */}
      <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
        <h3 className="font-bold text-gray-900 mb-8 flex items-center gap-2">
          <Filter className="text-green-600" size={20} /> Funil de Conversão Global
        </h3>
        
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={funnelData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f0f0f0" />
              <XAxis type="number" hide />
              <YAxis 
                dataKey="name" 
                type="category" 
                axisLine={false} 
                tickLine={false} 
                width={120}
                tick={{ fontSize: 11, fontWeight: 700, fill: '#64748b' }}
              />
              <Tooltip 
                cursor={{ fill: '#f8fafc' }}
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
              />
              <Bar dataKey="value" radius={[0, 12, 12, 0]}>
                {funnelData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={`rgba(16, 185, 129, ${1 - index * 0.15})`} 
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-6 flex justify-around text-center border-t border-gray-50 pt-8">
           <div>
             <p className="text-xl font-black text-gray-900">3.75%</p>
             <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">Conversão Final</p>
           </div>
           <div>
             <p className="text-xl font-black text-gray-900">70.8%</p>
             <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">Eficiência de Testes</p>
           </div>
           <div>
             <p className="text-xl font-black text-gray-900">37.5%</p>
             <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">Sucesso em Entrevista</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ManagerReports;
