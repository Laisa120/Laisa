
import React from 'react';
import { Application, Job } from '../types';
import { Calendar, Clock, MapPin, User, CheckCircle, MessageSquare } from 'lucide-react';

interface ManagerInterviewsProps {
  applications: Application[];
  jobs: Job[];
}

const ManagerInterviews: React.FC<ManagerInterviewsProps> = ({ applications, jobs }) => {
  const upcomingInterviews = applications.filter(a => a.interviewDate);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-900">Agenda de Entrevistas</h1>
        <p className="text-gray-500">Coordene os encontros presenciais e avaliações finais.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Próximas Entrevistas</h3>
          {upcomingInterviews.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-green-50 text-center flex flex-col items-center">
              <Calendar className="text-gray-200 mb-4" size={48} />
              <p className="text-gray-500">Nenhuma entrevista agendada para os próximos dias.</p>
            </div>
          ) : (
            upcomingInterviews.map(app => {
              const job = jobs.find(j => j.id === app.jobId);
              return (
                <div key={app.id} className="bg-white p-5 rounded-2xl border border-green-50 shadow-sm flex flex-col md:flex-row gap-4 items-start md:items-center justify-between hover:shadow-md transition-all">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-700">
                      <Calendar size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">ID: {app.candidateId}</h4>
                      <p className="text-xs font-medium text-green-600">{job?.title}</p>
                      <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                        <span className="flex items-center gap-1"><Clock size={12}/> {new Date(app.interviewDate!).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        <span className="flex items-center gap-1"><MapPin size={12}/> Sede Principal</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="px-4 py-2 bg-green-50 text-green-700 rounded-lg text-sm font-bold hover:bg-green-100 transition-colors">
                      Dar Feedback
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div className="bg-white p-6 rounded-3xl border border-green-100 shadow-sm flex flex-col h-fit">
          <div className="flex items-center gap-2 text-green-700 font-bold mb-6">
            <MessageSquare size={20} />
            <span>Registro de Feedback Pós-Entrevista</span>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-500 uppercase">Candidato Selecionado</label>
              <select className="w-full px-4 py-3 bg-gray-50 rounded-xl outline-none focus:ring-2 focus:ring-green-500">
                <option>Selecione uma entrevista realizada...</option>
                {upcomingInterviews.map(a => <option key={a.id}>Candidato {a.candidateId}</option>)}
              </select>
            </div>
            
            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-500 uppercase">Parecer Técnico</label>
              <textarea 
                rows={4} 
                className="w-full px-4 py-3 bg-gray-50 rounded-xl outline-none focus:ring-2 focus:ring-green-500"
                placeholder="Descreva os pontos fortes e fracos observados..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button className="py-3 bg-red-50 text-red-700 rounded-xl font-bold hover:bg-red-100 transition-colors">
                Reprovar
              </button>
              <button className="py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-colors shadow-lg shadow-green-100">
                Aprovar Contratação
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManagerInterviews;
