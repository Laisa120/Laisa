
import React from 'react';
import { Briefcase, User, LogOut, Layout, UserCircle } from 'lucide-react';

interface CandidateNavbarProps {
  userName: string;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  logoUrl: string;
}

const CandidateNavbar: React.FC<CandidateNavbarProps> = ({ userName, onLogout, activeTab, setActiveTab, logoUrl }) => {
  return (
    <nav className="bg-white border-b border-green-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex items-center gap-2 mr-4">
              <img 
                src={logoUrl} 
                alt="Logo Darcan" 
                className="w-8 h-8 object-contain rounded-lg"
                referrerPolicy="no-referrer"
              />
              <span className="text-xl font-bold text-green-700">Darcan Portal</span>
            </div>
            <div className="hidden sm:ml-8 sm:flex sm:space-x-8">
              <button
                onClick={() => setActiveTab('jobs')}
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors ${
                  activeTab === 'jobs' ? 'border-green-500 text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Vagas Disponíveis
              </button>
              <button
                onClick={() => setActiveTab('applications')}
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors ${
                  activeTab === 'applications' ? 'border-green-500 text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Minhas Candidaturas
              </button>
              <button
                onClick={() => setActiveTab('profile')}
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors ${
                  activeTab === 'profile' ? 'border-green-500 text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Meu Perfil
              </button>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer" onClick={() => setActiveTab('profile')}>
              <UserCircle size={20} className="text-green-600" />
              <span className="hidden sm:inline font-bold">{userName}</span>
            </div>
            <button
              onClick={onLogout}
              className="text-gray-400 hover:text-red-600 transition-colors"
              title="Sair"
            >
              <LogOut size={20} />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default CandidateNavbar;
