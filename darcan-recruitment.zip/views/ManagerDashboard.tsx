
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Users, Briefcase, FileCheck, CalendarCheck } from 'lucide-react';

const data = [
  { name: 'Triagem', value: 45, color: '#10b981' },
  { name: 'Testes', value: 30, color: '#34d399' },
  { name: 'Entrevista', value: 12, color: '#6ee7b7' },
  { name: 'Aprovados', value: 5, color: '#059669' },
];

const StatCard = ({ title, value, icon: Icon, trend }: any) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-green-50">
    <div className="flex justify-between items-start">
      <div className="min-w-0">
        <p className="text-sm text-gray-500 font-medium truncate">{title}</p>
        <h3 className="text-2xl font-bold mt-1 text-gray-900">{value}</h3>
      </div>
      <div className="p-2 bg-green-50 rounded-lg text-green-600 shrink-0">
        <Icon size={24} />
      </div>
    </div>
    {trend && (
      <p className={`text-xs mt-3 ${trend.positive ? 'text-green-600' : 'text-red-500'}`}>
        {trend.positive ? '↑' : '↓'} {trend.value}% vs mês passado
      </p>
    )}
  </div>
);

const ManagerDashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard de Recrutamento</h1>
        <p className="text-gray-500 text-sm sm:text-base">Bem-vindo de volta! Aqui está o resumo das atividades.</p>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <StatCard title="Vagas Abertas" value="12" icon={Briefcase} trend={{ value: 8, positive: true }} />
        <StatCard title="Total Candidatos" value="348" icon={Users} trend={{ value: 12, positive: true }} />
        <StatCard title="Testes Pendentes" value="28" icon={FileCheck} />
        <StatCard title="Entrevistas Hoje" value="4" icon={CalendarCheck} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-4 sm:p-6 rounded-xl shadow-sm border border-green-50 overflow-hidden">
          <h3 className="text-lg font-semibold mb-6">Candidatos por Fase</h3>
          <div className="h-64 sm:h-72 lg:h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <Tooltip cursor={{ fill: '#f8fafc' }} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-4 sm:p-6 rounded-xl shadow-sm border border-green-50">
          <h3 className="text-lg font-semibold mb-4">Atividades Recentes</h3>
          <div className="space-y-4">
            {[
              { text: "João Silva candidatou-se à vaga de Professor de Matemática", time: "Há 10 min", type: "candidate" },
              { text: "Teste online de Maria Costa submetido para avaliação", time: "Há 45 min", type: "test" },
              { text: "Vaga 'Analista Financeiro' arquivada por Admin", time: "Há 2 horas", type: "admin" },
              { text: "Entrevista agendada com Roberto Santos", time: "Há 3 horas", type: "interview" },
            ].map((activity, i) => (
              <div key={i} className="flex gap-3 pb-3 border-b border-gray-50 last:border-0">
                <div className="w-2 h-2 mt-2 rounded-full bg-green-500 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-800 leading-tight">{activity.text}</p>
                  <span className="text-xs text-gray-400 block mt-1">{activity.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManagerDashboard;
